import torch
import pandas as pd
import torch.nn as nn
import time
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
from kan import KAN  # 假设 'kan' 库中有 KAN 类
from kan import *
# 设置中文字体和负号显示
plt.rcParams['font.sans-serif'] = ['SimHei']  
plt.rcParams['axes.unicode_minus'] = False  

# 定义 KANConv 类，继承自 KAN
class KANConv(KAN):
    def __init__(self, width, input_size, window_size, hidden_sizes, grid=5, k=3, noise_scale=0.3, device='cuda'):
        super().__init__(
            width=width,
            grid=grid,
            k=k,
            noise_scale=noise_scale,
            device=device
        )
        
        self.window_size = window_size
        self.input_size = input_size
        
        self.conv_layer = nn.Conv1d(
            in_channels=input_size,
            out_channels=input_size,  
            kernel_size=window_size,
            stride=1,
            padding=window_size//2,
            groups=input_size  # 深度可分离卷积
        )
        
        self.device = device
        self.to(device)

    def forward(self, x, singularity_avoiding=False, y_th=10.):
        # x shape: [batch_size, window_size, n_features]
        batch_size = x.shape[0]
        
        # 应用卷积预处理
        x_conv = x.permute(0, 2, 1)  # [batch_size, n_features, window_size]
        x_conv = self.conv_layer(x_conv)
        x_conv = x_conv.permute(0, 2, 1)  # [batch_size, window_size, n_features]
        
        # 只使用最后一个时间步的特征作为 KAN 的输入
        x_last = x_conv[:, -1, :]  # [batch_size, n_features]
        
        # 通过 KAN 网络处理
        out = super().forward(x_last, singularity_avoiding=singularity_avoiding, y_th=y_th)
        
        return out

def create_sequences(data, window_size):
    """
    使用滑动窗口方法从标准化后的数据中创建输入序列和对应的目标值。
    """
    X = []
    y = []
    for i in range(len(data) - window_size):
        X.append(data[i:i+window_size])
        y.append(data[i+window_size])
    X = np.array(X)
    y = np.array(y)
    return X, y

def prepare_train_data_for_kanconv(training_dfs, window_size, device):
    """
    准备训练数据，合并多个 DataFrame，标准化，并创建序列。
    """
    load_data_list = []
    for df in training_dfs:
        load_data = df.iloc[:, 3:].values.T  # 转置为 (时间点数量, 区域数量)
        load_data_list.append(load_data)
    
    # 沿时间轴（行）合并数据
    concatenated_load_data = np.vstack(load_data_list)  # shape: (total_time_points, regions)
    print(f"合并后的训练负荷数据形状: {concatenated_load_data.shape}")
    
    # 数据标准化
    scaler = MinMaxScaler()
    load_data_scaled = scaler.fit_transform(concatenated_load_data)
    print(f"标准化后的训练负荷数据形状: {load_data_scaled.shape}")
    
    # 创建序列
    X, y = create_sequences(load_data_scaled, window_size)
    print(f"训练序列 - X 形状: {X.shape}, y 形状: {y.shape}")
    
    # 转换为张量并移动到设备
    X = torch.FloatTensor(X).to(device)
    y = torch.FloatTensor(y).to(device)
    
    # 创建训练数据字典
    train_dataset = {
        'train_input': X,
        'train_label': y
    }
    
    return train_dataset, scaler

def prepare_test_data_for_kanconv(test_df, window_size, scaler, device):
    """
    准备测试数据，使用训练时拟合的标准化器，并创建序列。
    """
    load_data = test_df.iloc[:, 3:].values.T  # 转置为 (时间点数量, 区域数量)
    print(f"原始测试负荷数据形状: {load_data.shape}")
    
    # 使用训练时的 scaler 进行转换
    load_data_scaled = scaler.transform(load_data)
    print(f"标准化后的测试负荷数据形状: {load_data_scaled.shape}")
    
    # 创建序列
    X, y = create_sequences(load_data_scaled, window_size)
    print(f"测试序列 - X 形状: {X.shape}, y 形状: {y.shape}")
    
    # 转换为张量并移动到设备
    X = torch.FloatTensor(X).to(device)
    y = torch.FloatTensor(y).to(device)
    
    # 创建测试数据字典
    test_dataset = {
        'test_input': X,
        'test_label': y
    }
    
    return test_dataset

def train_kan_model(model, dataset, steps=500, lamb=0.01):
    """
    训练 KAN 模型。
    """
    results = model.fit(
        dataset,
        opt='Adam',
        steps=steps,
        lr=3e-4,
        lamb=lamb,
        lamb_entropy=0.,
        update_grid=True
    )
    
    return results

def predict_and_plot_kan(model, test_dataset, scaler, test_df, device, start_time=None):
    """
    使用 KAN 模型进行预测并绘制结果。
    """
    model.eval()
    with torch.no_grad():
        predictions = model(test_dataset['test_input']).cpu().numpy()
        actuals = test_dataset['test_label'].cpu().numpy()
    
    print(f"预测数据形状: {predictions.shape}")
    print(f"实际数据形状: {actuals.shape}")
    
    # 反标准化
    predictions = scaler.inverse_transform(predictions)
    actuals = scaler.inverse_transform(actuals)
    
    # 计算总体评估指标
    mse = np.mean((predictions - actuals) ** 2)
    rmse = np.sqrt(mse)
    mae = np.mean(np.abs(predictions - actuals))
    mape = np.mean(np.abs((actuals - predictions) / actuals)) * 100
    r2 = 1 - np.sum((actuals - predictions) ** 2) / np.sum((actuals - np.mean(actuals)) ** 2)
    
    # 计算运行时间
    end_time = time.time()
    run_time = end_time - start_time if start_time else None
    metrics = {
        'rmse': rmse,
        'mape': mape,
        'r2': r2,
        'time': run_time if run_time is not None else 0.0
    }        
    
    # 获取区域名称
    region_names = test_df.iloc[:, 0].unique()
    
    # 为每个区域绘制预测结果
    n_regions = len(region_names)
    n_cols = 3
    n_rows = (n_regions + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(20, 6 * n_rows))
    fig.suptitle('各区域负荷预测结果对比', fontsize=16, y=0.95)
    axes = axes.ravel()
    output_path = 'predicted_load_data_KAN-CNN.csv'
    predictions_df = save_predictions_to_csv(predictions, test_df, output_path, window_size=8)
    print(f"预测结果已保存至: {output_path}")
    for i in range(min(len(region_names), predictions.shape[1])):
        ax = axes[i]
        ax.plot(actuals[:, i], label='实际值', alpha=0.7, linewidth=2)
        ax.plot(predictions[:, i], label='预测值', alpha=0.7, linewidth=2, linestyle='--')
        ax.set_title(f'区域: {region_names[i]}')
        ax.set_xlabel('时间点')
        ax.set_ylabel('负荷值')
        ax.legend(loc='upper right')
        ax.grid(True, linestyle='--', alpha=0.7)
        ax.tick_params(axis='both', labelsize=10)
        
    # 隐藏多余的子图
    for i in range(len(region_names), len(axes)):
        axes[i].set_visible(False)
    
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()
    
    # 计算并打印各区域评估指标
    print('\n预测效果评估:')
    print('=' * 50)
    for i in range(min(len(region_names), predictions.shape[1])):
        region = region_names[i]
        mse = np.mean((predictions[:, i] - actuals[:, i]) ** 2)
        rmse = np.sqrt(mse)
        mae = np.mean(np.abs(predictions[:, i] - actuals[:, i]))
        mape = np.mean(np.abs((actuals - predictions) / actuals)) * 100
        
        print(f'\n{region} 区域:')
        print(f'均方误差 (MSE): {mse:.2f}')
        print(f'均方根误差 (RMSE): {rmse:.2f}')
        print(f'平均绝对误差 (MAE): {mae:.2f}')
        print(f'平均绝对百分比误差 (MAPE): {mape:.2f}%')
        
    return predictions, actuals, metrics
def save_predictions_to_csv(predictions, test_df, output_path, window_size):
    """
    将模型预测结果保存为与原始数据格式一致的CSV文件
    """
    import pandas as pd
    import numpy as np
    
    # 获取原始数据的列名
    original_columns = test_df.columns.tolist()
    
    # 获取基础信息（管理单位、充电桩数）
    base_info = test_df[['管理单位', '充电桩数']].copy()
    
    # 准备时间序列数据
    time_columns = original_columns[3:]  # 所有时间点列名
    
    # 创建结果DataFrame
    result_df = pd.DataFrame(columns=original_columns)
    result_df[['管理单位', '充电桩数']] = base_info.values
    
    # 初始化预测数据数组
    n_regions = len(base_info)
    n_timepoints = len(time_columns)
    pred_data = np.zeros((n_regions, n_timepoints))
    
    # 获取原始数据用于填充开始部分
    original_data = test_df[time_columns].values
    
    # 填充开始部分（前window_size个时间点）使用原始数据
    pred_data[:, :window_size] = original_data[:, :window_size]
    
    # 填充预测部分
    if len(predictions.shape) == 2:
        pred_data[:, window_size:] = predictions.T
    else:
        # 如果predictions是一维数组，需要重塑
        reshaped_predictions = predictions.reshape(-1, n_regions).T
        pred_data[:, window_size:window_size+len(reshaped_predictions[0])] = reshaped_predictions
    
    # 填充预测数据到DataFrame
    for i, col in enumerate(time_columns):
        result_df[col] = pred_data[:, i]
    
    # 计算总负荷
    result_df['总负荷'] = result_df[time_columns].sum(axis=1)
    
    # 确保所有数值列保留4位小数
    numeric_columns = ['总负荷'] + time_columns
    result_df[numeric_columns] = result_df[numeric_columns].round(4)
    
    # 保存为CSV文件
    result_df.to_csv(output_path, index=False)
    
    print(f"预测数据形状: {predictions.shape}")
    print(f"原始数据形状: {original_data.shape}")
    print(f"最终数据形状: {pred_data.shape}")
    
    return result_df
def main():
    # 设置随机种子
    torch.manual_seed(42)
    np.random.seed(42)
    start_time = time.time()
    
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")
    
    # 模型参数
    input_size = 7  # 区域数量
    window_size = 8  # 滑动窗口大小
    hidden_sizes = [14, 14]  # KAN隐藏层大小（根据需要调整）
    
    # 定义训练 CSV 文件路径（查询结果 (1) 到 查询结果 (5)）
    training_paths = [
        '/data/数据/202408/查询结果 (1).csv',
        '/data/数据/202408/查询结果 (2).csv',
        '/data/数据/202408/查询结果 (3).csv',
        '/data/数据/202408/查询结果 (4).csv',
        '/data/数据/202408/查询结果 (5).csv'
    ]
    
    # 读取并加载训练数据
    training_dfs = []
    for path in training_paths:
        print(f"读取训练数据: {path}")
        df = pd.read_csv(path)
        training_dfs.append(df)
        print(f"读取成功，数据集形状: {df.shape}")
    
    # 准备训练数据，拟合标准化器
    train_dataset, scaler = prepare_train_data_for_kanconv(training_dfs, window_size, device)
    print(f"训练集大小: {len(train_dataset['train_input'])}")
    
    # Read the test CSV file
    test_path = '/data/数据/202408/查询结果 (6).csv'
    print(f"读取测试数据: {test_path}")
    test_df = pd.read_csv(test_path)
    print("测试数据加载成功")
    print(f"测试数据集形状: {test_df.shape}")
    
    # 准备测试数据，使用相同的标准化器
    test_dataset = prepare_test_data_for_kanconv(test_df, window_size, scaler=scaler, device=device)
    print(f"测试集大小: {len(test_dataset['test_input'])}")
    
    # 创建数据集字典，包含训练和测试数据
    dataset = {
        'train_input': train_dataset['train_input'],
        'train_label': train_dataset['train_label'],
        'test_input': test_dataset['test_input'],
        'test_label': test_dataset['test_label']
    }
    
    # 初始化 KANConv 模型
    model = KANConv(
        width=[[7, 0], 
               [28, 0],
               [42, 0],
               [7, 0]],
        input_size=input_size,
        window_size=window_size,
        hidden_sizes=hidden_sizes,
        grid=3,                # 网格间隔数
        k=3,                  # 样条阶数
        noise_scale=0.2,      # 初始噪声 scale
        device=device
    )
   
    # 训练模型
    print("开始训练...")
    results = train_kan_model(model, dataset, steps=400, lamb=0.00001)
    
    # 绘制训练损失曲线
    plt.figure(figsize=(10, 6))
    plt.plot(results['train_loss'], marker='o')
    plt.title('训练损失')
    plt.xlabel('步骤')
    plt.ylabel('损失')
    plt.grid(True)
    plt.show()
    
    # 预测并绘制结果
    print("开始预测...")
    predictions, actuals, metrics = predict_and_plot_kan(model, dataset, scaler, test_df, device, start_time)
    
    # 保存模型和标准化器
    model.saveckpt('load_predictor_kanconv')
    print("模型保存成功")
    
    # 打印评估结果汇总表
    print("\n评估结果汇总表：")
    print("=" * 60)
    print("Method    RMSE(MW)    MAPE(%)    R²        Time(s)")
    print("-" * 60)
    print(f"KAN       {metrics['rmse']:.3f}      {metrics['mape']:.3f}    {metrics['r2']:.2f}    {metrics['time']:.1f}")
    
    # 进行符号回归（假设 'auto_symbolic' 方法存在）
    lib = ['x','x^2','x^3','x^4','exp','log','sqrt','tanh','sin','tan','abs']
    # lib = ['x']  # 可根据需要调整
    model.auto_symbolic(lib=lib)
    formulas = model.symbolic_formula()[0]
    for i in formulas:
        print(ex_round(i, 4))  # 假设 ex_round 是一个四舍五入函数
    print(formulas)

if __name__ == "__main__":
    main()
