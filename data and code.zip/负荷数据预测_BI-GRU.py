import torch
import torch.nn as nn
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from torch.utils.data import Dataset, DataLoader, TensorDataset
import matplotlib.pyplot as plt
import time

# 设置中文字体和负号显示
plt.rcParams['font.sans-serif'] = ['SimHei']  
plt.rcParams['axes.unicode_minus'] = False  

# 定义数据集类
class LoadDataset(Dataset):
    def __init__(self, data, seq_length):
        self.data = torch.FloatTensor(data)
        self.seq_length = seq_length

    def __len__(self):
        return max(0, len(self.data) - self.seq_length)

    def __getitem__(self, index):
        x = self.data[index:index + self.seq_length]
        y = self.data[index + self.seq_length]
        return x, y

# 定义双向 GRU 预测模型
class BiGRUPredictor(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size, dropout=0.2):
        super(BiGRUPredictor, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        # 双向 GRU
        self.gru = nn.GRU(
            input_size, 
            hidden_size, 
            num_layers, 
            batch_first=True,
            bidirectional=True,  # 启用双向 GRU
            dropout=dropout if num_layers > 1 else 0
        )
        
        # 双向 GRU 隐藏层维度翻倍
        self.fc = nn.Linear(hidden_size * 2, hidden_size)  # 第一个全连接层
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        self.fc_out = nn.Linear(hidden_size, output_size)  # 输出层
        
    def forward(self, x):
        # 初始化隐藏状态，注意维度需要翻倍，GRU 不需要细胞状态
        h0 = torch.zeros(self.num_layers * 2, x.size(0), self.hidden_size).to(x.device)
        
        # GRU 前向传播
        out, _ = self.gru(x, h0)
        
        # 只使用最后一个时间步的输出
        out = self.fc(out[:, -1, :])
        out = self.relu(out)
        out = self.dropout(out)
        out = self.fc_out(out)
        
        return out

# 创建序列
def create_sequences(data, seq_length):
    xs = []
    ys = []
    for i in range(len(data) - seq_length):
        x = data[i:(i + seq_length)]
        y = data[i + seq_length]
        xs.append(x)
        ys.append(y)
    return np.array(xs), np.array(ys)

# 准备训练数据
def prepare_train_data(training_dfs, seq_length):
    # 合并多个训练 DataFrame 的负荷数据
    load_data_list = []
    for df in training_dfs:
        # 假设负荷数据从第4列开始
        load_data = df.iloc[:, 3:].values.T  # 转置为 (时间点数量, 区域数量)
        load_data_list.append(load_data)
    
    # 沿时间轴（行）合并数据
    concatenated_load_data = np.vstack(load_data_list)  # shape: (total_time_points, regions)
    print(f"合并后的训练负荷数据形状: {concatenated_load_data.shape}")
    
    # 数据标准化
    scaler = MinMaxScaler()
    load_data_scaled = scaler.fit_transform(concatenated_load_data)
    print(f"标准化后的训练负荷数据形状: {load_data_scaled.shape}")
    
    # 创建序列
    X, y = create_sequences(load_data_scaled, seq_length)
    print(f"训练序列 - X 形状: {X.shape}, y 形状: {y.shape}")
    
    # 创建 TensorDataset
    train_dataset = TensorDataset(
        torch.FloatTensor(X), 
        torch.FloatTensor(y)
    )
    
    return train_dataset, scaler

# 准备测试数据
def prepare_test_data(test_df, seq_length, scaler):
    # 提取负荷数据
    load_data = test_df.iloc[:, 3:].values.T  # 转置为 (时间点数量, 区域数量)
    print(f"原始测试负荷数据形状: {load_data.shape}")
    
    # 使用训练时的 scaler 进行转换
    load_data_scaled = scaler.transform(load_data)
    print(f"标准化后的测试负荷数据形状: {load_data_scaled.shape}")
    
    # 创建序列
    X, y = create_sequences(load_data_scaled, seq_length)
    print(f"测试序列 - X 形状: {X.shape}, y 形状: {y.shape}")
    
    # 创建 TensorDataset
    test_dataset = TensorDataset(
        torch.FloatTensor(X), 
        torch.FloatTensor(y)
    )
    
    return test_dataset

# 训练模型
def train_model(model, train_loader, criterion, optimizer, num_epochs, device, scheduler=None):
    model = model.to(device)
    train_losses = []
    best_loss = float('inf')
    
    for epoch in range(num_epochs):
        model.train()
        total_loss = 0
        batch_count = 0
        
        for batch_x, batch_y in train_loader:
            batch_x = batch_x.to(device)
            batch_y = batch_y.to(device)
            
            optimizer.zero_grad()
            output = model(batch_x)
            loss = criterion(output, batch_y)
            loss.backward()
            
            # 梯度裁剪，防止梯度爆炸
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            
            optimizer.step()
            
            total_loss += loss.item()
            batch_count += 1
        
        avg_loss = total_loss / batch_count
        train_losses.append(avg_loss)
        
        # 学习率调度
        if scheduler is not None:
            scheduler.step(avg_loss)  # 传入当前 epoch 的平均损失
            
        # 保存最佳模型
        if avg_loss < best_loss:
            best_loss = avg_loss
        
        if (epoch + 1) % 10 == 0:
            print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {avg_loss:.6f}, Best Loss: {best_loss:.6f}')
    
    return train_losses

# 绘制训练损失曲线
def plot_losses(losses):
    plt.figure(figsize=(10, 6))
    plt.plot(losses, marker='o')
    plt.xlabel('训练轮次')
    plt.ylabel('损失值')
    plt.title('训练过程中的损失变化')
    plt.grid(True)
    plt.show()

# 预测并绘制结果
def predict_and_plot(model, test_loader, scaler, test_df, device, start_time=None):
    model.eval()
    predictions = []
    actuals = []
    
    with torch.no_grad():
        for batch_x, batch_y in test_loader:
            batch_x = batch_x.to(device)
            output = model(batch_x)
            predictions.append(output.cpu().numpy())
            actuals.append(batch_y.cpu().numpy())
    
    predictions = np.concatenate(predictions, axis=0)
    actuals = np.concatenate(actuals, axis=0)
    
    print(f"预测数据形状: {predictions.shape}")
    print(f"实际数据形状: {actuals.shape}")
    
    # 反标准化
    predictions = scaler.inverse_transform(predictions)
    actuals = scaler.inverse_transform(actuals)
    
    # 计算总体评估指标
    mse = np.mean((predictions - actuals) ** 2)
    rmse = np.sqrt(mse)
    mae = np.mean(np.abs(predictions - actuals))
    mape = np.mean(np.abs((actuals - predictions) / actuals)) * 100
    r2 = 1 - np.sum((actuals - predictions) ** 2) / np.sum((actuals - np.mean(actuals)) ** 2)
    
    # 计算运行时间
    end_time = time.time()
    run_time = end_time - start_time if start_time else None

    # 获取区域名称
    # 假设区域名称在第1列
    region_names = test_df.iloc[:, 0].values
    
    # 为每个区域绘制预测结果
    n_regions = len(region_names)
    n_cols = 3
    n_rows = (n_regions + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(20, 6 * n_rows))
    fig.suptitle('各区域负荷预测结果对比', fontsize=16, y=0.95)
    axes = axes.ravel()
    output_path = 'predicted_load_data_Bi-GRU.csv'
    predictions_df = save_predictions_to_csv(predictions, test_df, output_path, window_size=8)    
    for i in range(min(len(region_names), predictions.shape[1])):
        ax = axes[i]
        ax.plot(actuals[:, i], label='实际值', alpha=0.7, linewidth=2)
        ax.plot(predictions[:, i], label='预测值', alpha=0.7, linewidth=2, linestyle='--')
        ax.set_title(f'区域: {region_names[i]}')
        ax.set_xlabel('时间点')
        ax.set_ylabel('负荷值')
        ax.legend(loc='upper right')
        ax.grid(True, linestyle='--', alpha=0.7)
        ax.tick_params(axis='both', labelsize=10)
    
    # 隐藏多余的子图
    for i in range(len(region_names), len(axes)):
        axes[i].set_visible(False)
    
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()

    # 创建评估指标字典
    metrics = {
        'rmse': rmse,
        'mape': mape,
        'r2': r2,
        'time': run_time if run_time is not None else 0.0
    }
    
    return predictions, actuals, metrics
def save_predictions_to_csv(predictions, test_df, output_path, window_size):
    """
    将模型预测结果保存为与原始数据格式一致的CSV文件
    """
    import pandas as pd
    import numpy as np
    
    # 获取原始数据的列名
    original_columns = test_df.columns.tolist()
    
    # 获取基础信息（管理单位、充电桩数）
    base_info = test_df[['管理单位', '充电桩数']].copy()
    
    # 准备时间序列数据
    time_columns = original_columns[3:]  # 所有时间点列名
    
    # 创建结果DataFrame
    result_df = pd.DataFrame(columns=original_columns)
    result_df[['管理单位', '充电桩数']] = base_info.values
    
    # 初始化预测数据数组
    n_regions = len(base_info)
    n_timepoints = len(time_columns)
    pred_data = np.zeros((n_regions, n_timepoints))
    
    # 获取原始数据用于填充开始部分
    original_data = test_df[time_columns].values
    
    # 填充开始部分（前window_size个时间点）使用原始数据
    pred_data[:, :window_size] = original_data[:, :window_size]
    
    # 填充预测部分
    if len(predictions.shape) == 2:
        pred_data[:, window_size:] = predictions.T
    else:
        # 如果predictions是一维数组，需要重塑
        reshaped_predictions = predictions.reshape(-1, n_regions).T
        pred_data[:, window_size:window_size+len(reshaped_predictions[0])] = reshaped_predictions
    
    # 填充预测数据到DataFrame
    for i, col in enumerate(time_columns):
        result_df[col] = pred_data[:, i]
    
    # 计算总负荷
    result_df['总负荷'] = result_df[time_columns].sum(axis=1)
    
    # 确保所有数值列保留4位小数
    numeric_columns = ['总负荷'] + time_columns
    result_df[numeric_columns] = result_df[numeric_columns].round(4)
    
    # 保存为CSV文件
    result_df.to_csv(output_path, index=False)
    
    print(f"预测数据形状: {predictions.shape}")
    print(f"原始数据形状: {original_data.shape}")
    print(f"最终数据形状: {pred_data.shape}")
    
    return result_df
# 主函数
def main():
    # 设置随机种子
    torch.manual_seed(42)
    np.random.seed(42)
    
    # 记录开始时间
    start_time = time.time()
    
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")
    
    # 模型参数
    input_size = 7  # 7个区域
    hidden_size = 256  # 隐藏层大小
    num_layers = 2    # GRU层数
    output_size = 7
    seq_length = 8   # 滑动窗口大小
    batch_size = 16   # Batch size
    num_epochs = 140
    learning_rate = 0.001  # 学习率
    dropout = 0.1     # Dropout率

    # 初始化模型
    model = BiGRUPredictor(input_size, hidden_size, num_layers, output_size, dropout)
    model = model.to(device)
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    
    # 添加学习率调度器
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, 
        mode='min', 
        factor=0.5, 
        patience=20, 
        verbose=True
    )

    # 定义训练 CSV 文件路径（查询结果 (1) 到 查询结果 (5)）
    training_paths = [
        '/data/数据/202408/查询结果 (1).csv',
        '/data/数据/202408/查询结果 (2).csv',
        '/data/数据/202408/查询结果 (3).csv',
        '/data/数据/202408/查询结果 (4).csv',
        '/data/数据/202408/查询结果 (5).csv'
    ]
    
    # 读取并加载训练数据
    training_dfs = []
    for path in training_paths:
        print(f"读取训练数据: {path}")
        df = pd.read_csv(path)
        training_dfs.append(df)
        print(f"读取成功，数据集形状: {df.shape}")
    
    # 准备训练数据，拟合标准化器
    train_dataset, scaler = prepare_train_data(training_dfs, seq_length)
    print(f"训练集大小: {len(train_dataset)}")
    
    # 创建训练数据加载器
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    
    # 定义测试 CSV 文件路径（查询结果 (6)）
    test_path = '/data/数据/202408/查询结果 (6).csv'
    print(f"读取测试数据: {test_path}")
    test_df = pd.read_csv(test_path)
    print("测试数据加载成功")
    print(f"测试数据集形状: {test_df.shape}")
    
    # 准备测试数据，使用相同的标准化器
    test_dataset = prepare_test_data(test_df, seq_length, scaler=scaler)
    print(f"测试集大小: {len(test_dataset)}")
    
    # 创建测试数据加载器
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    # 获取区域数量
    num_regions = train_dataset.tensors[1].shape[1]  # y 形状: [samples, regions]
    print(f"区域数量: {num_regions}")
    
    # 动态调整模型的输入和输出维度（如果区域数量不同）
    if num_regions != input_size:
        input_size = num_regions
        output_size = num_regions
        model = BiGRUPredictor(input_size, hidden_size, num_layers, output_size, dropout)
        model = model.to(device)
        print(f"调整后的输入和输出维度: {input_size}")
    
    # 训练模型
    print("开始训练...")
    train_losses = train_model(model, train_loader, criterion, optimizer, num_epochs, device, scheduler)
    
    # 绘制训练损失曲线
    plot_losses(train_losses)
    
    # 预测并绘制结果
    print("开始预测...")
    predictions, actuals, metrics = predict_and_plot(model, test_loader, scaler, test_df, device, start_time)
    
    # 打印评估结果汇总表
    print("\n评估结果汇总表：")
    print("=" * 60)
    print("Method     RMSE(MW)    MAPE(%)    R²        Time(s)")
    print("-" * 60)
    print(f"Bi-GRU     {metrics['rmse']:.3f}      {metrics['mape']:.3f}    {metrics['r2']:.2f}    {metrics['time']:.1f}")
    
    # 保存模型和标准化器
    torch.save({
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'train_losses': train_losses,
        'scaler': scaler
    }, 'bigru_predictor.pth')
    print("\n模型和Scaler保存成功")

if __name__ == "__main__":
    main()
